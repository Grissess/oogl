function Primitive(prim, indices) {
	this.prim = prim;
	this.indices = indices;
}

Primitive.prototype.draw = function(prog) {
	prog.drawIndexed(this.prim, this.indices);
}

function Polytope() {
	arguments = Array.apply(null, arguments);
	this.points = arguments.shift();
	this.primitives = arguments;
}

Polytope.prototype.draw = function(prog) {
	for(var i = 0; i < this.primitives.length; i++) {
		this.primitives[i].draw(prog);
	}
}

var polytope = new (function() {
	function enumeration(len, orig, stride) {
		if(orig == undefined) orig = 0;
		if(stride == undefined) stride = 1;
		var ret = new Array(len);
		for(var i = 0; i < len; i++) {
			ret[i] = stride * i + orig;
		}
		return new Buffer(ret, Uint16Array, gl.ELEMENT_ARRAY_BUFFER);
	}
	this.enumeration = enumeration;

	function circle(resolution) {
		var pts = [];
		for(var theta = 0; theta < 2*Math.PI; theta += 2*Math.PI / resolution) {
			pts.push(vec2(Math.cos(theta), Math.sin(theta)));
		}
		return new Polytope(new Buffer(pts), new Primitive(gl.TRIANGLE_FAN, enumeration(pts.length)));
	}
	this.circle = circle;

	function cgram(resolution, ir) {
		var pts = [];
		for(var theta = 0; theta < 2*Math.PI; theta += 2*Math.PI / resolution) {
			pts.push(vec2(Math.cos(theta), Math.sin(theta)));
		}
		var halfang = Math.PI / resolution;
		pts = pts.concat(pts.map(function(elem) {
			return vec2(
				ir * (elem[0] * Math.cos(halfang) - elem[1] * Math.sin(halfang)),
				ir * (elem[0] * Math.sin(halfang) + elem[1] * Math.cos(halfang))
			);
		}));
		var innerorig = pts.length / 2;
		var tris = [pts.length - 1, 0, innerorig];
		for(var i = 1; i < innerorig; i++) {
			tris.push(innerorig + i , i, innerorig + i - 1);
		}
		return new Polytope(
			new Buffer(pts),
			new Primitive(gl.TRIANGLE_FAN, enumeration(innerorig, innerorig)),
			new Primitive(gl.TRIANGLES, new Buffer(tris, Uint16Array, gl.ELEMENT_ARRAY_BUFFER))
		);
	}
	this.cgram = cgram

	function cross(arms, width) {
		var pts = [];
		for(var theta = 0; theta < 2*Math.PI; theta += 2*Math.PI / arms) {
			var pt = vec2(Math.cos(theta), Math.sin(theta));
			var tan = vec2(-Math.sin(theta), Math.cos(theta));
			var hwv = vec2(width/2, width/2);
			var tanoff = mult(tan, hwv);
			pts.push(
				add(pt, tanoff),
				subtract(pt, tanoff)
			);
		}
		var diag = width / (2 * Math.sin(2*Math.PI / arms));
		var rad = Math.sqrt(2 * diag * diag - 2 * diag * diag * Math.cos(180 - (2*Math.PI / arms)));
		for(var theta = Math.PI / arms; theta < 2*Math.PI; theta += 2*Math.PI / arms) {
			pts.push(vec2(rad * Math.cos(theta), rad * Math.sin(theta)));
		}
		var seg2 = arms;
		var seg3 = 2 * seg2;
		var tris = [1, 0, seg3, 1, pts.length-1, seg3];
		for(var i = 1; i < arms; i++) {
			tris.push(
				2*i+1, 2*i, seg3+i,
				2*i+1, seg3+i-1, seg3+i
			);
		}
		return new Polytope(
			new Buffer(pts),
			new Primitive(gl.TRIANGLE_FAN, enumeration(arms, seg3)),
			new Primitive(gl.TRIANGLES, new Buffer(tris, Uint16Array, gl.ELEMENT_ARRAY_BUFFER))
		);
	}
	this.cross = cross;

	function cylinder(resolution) {
		// Point generation
		var pts = [];
		for(var theta = 0; theta < 2*Math.PI; theta += 2*Math.PI / resolution) {
			pts.push(vec3(Math.cos(theta), Math.sin(theta), 1));
		}
		pts = pts.concat(pts.map(function(elem) { return vec3(elem[0], elem[1], -elem[2]); }));
		var bhalf = pts.length / 2;
		// Face generation
		var faces = [];
		var i;
		// - Upper circle triangle strip
		for(i = 1; i < bhalf - 1; i++) {
			faces.push(0, i, i+1);
		}
		// - Lower circle
		for(i = bhalf + 1; i < pts.length - 1; i++) {
			faces.push(bhalf, i, i+1);
		}
		// - Body quads
		for(i = 0; i < bhalf -1; i++) {
			faces.push(i, i + bhalf, i + bhalf + 1, i, i + bhalf + 1, i + 1);
		}
		// - Final body quad for loop
		faces.push(bhalf - 1, pts.length - 1, bhalf, bhalf - 1, bhalf, 0);
		return new Polytope(new Buffer(pts), new Primitive(gl.TRIANGLES, new Buffer(faces, Uint16Array, gl.ELEMENT_ARRAY_BUFFER)));
	}
	this.cylinder = cylinder;
})();
