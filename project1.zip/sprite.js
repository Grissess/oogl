function Sprite() {}

Sprite.prototype.draw()
